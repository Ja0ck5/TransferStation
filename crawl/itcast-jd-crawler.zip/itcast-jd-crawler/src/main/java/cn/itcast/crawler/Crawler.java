package cn.itcast.crawler;

public interface Crawler extends Runnable{
	
}
